// File - lib/features/dev/widgets/dev_provider_panel.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:gofamily/features/home/weather_controller.dart';
import 'package:gofamily/features/kids/missions/missions_controller.dart';
import 'package:gofamily/features/kids/stickers/stickers_controller.dart';
import 'package:gofamily/features/safety/safety_controller.dart';

class DevProviderPanel extends ConsumerWidget {
  const DevProviderPanel({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final missions = ref.watch(missionsControllerProvider);
    final stickers = ref.watch(stickersControllerProvider);
    final weather = ref.watch(weatherControllerProvider);
    final safety = ref.watch(safetyControllerProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Provider States')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Provider Debug Panel',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),

          // -------------------------
          // MISSIONS
          // -------------------------
          ExpansionTile(
            title: const Text('MissionsController'),
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: buildAsyncTile(missions),
              ),
              OverflowBar(
                spacing: 8,
                children: [
                  ElevatedButton(
                    onPressed: () {
                      ref.invalidate(missionsControllerProvider);
                    },
                    child: const Text('Reload'),
                  ),
                ],
              ),
            ],
          ),

          // -------------------------
          // STICKERS
          // -------------------------
          ExpansionTile(
            title: const Text('StickersController'),
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: buildAsyncTile(stickers),
              ),
              OverflowBar(
                spacing: 8,
                children: [
                  ElevatedButton(
                    onPressed: () {
                      ref.invalidate(stickersControllerProvider);
                    },
                    child: const Text('Reload'),
                  ),
                ],
              ),
            ],
          ),

          // -------------------------
          // WEATHER
          // -------------------------
          ExpansionTile(
            title: const Text('WeatherController'),
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: buildAsyncTile(weather),
              ),
              OverflowBar(
                spacing: 8,
                children: [
                  ElevatedButton(
                    onPressed: () {
                      ref.invalidate(weatherControllerProvider);
                    },
                    child: const Text('Refresh'),
                  ),
                ],
              ),
            ],
          ),

          // -------------------------
          // SAFETY
          // -------------------------
          ExpansionTile(
            title: const Text('SafetyController'),
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: buildAsyncTile(safety),
              ),
              OverflowBar(
                spacing: 8,
                children: [
                  ElevatedButton(
                    onPressed: () {
                      ref.invalidate(safetyControllerProvider);
                    },
                    child: const Text('Reload'),
                  ),
                ],
              ),
            ],
          ),

          // -------------------------
          // TRAVEL (Stub)
          // -------------------------
          const ExpansionTile(
            title: Text('TravelController'),
            children: [
              Padding(
                padding: EdgeInsets.all(8.0),
                child: Text(
                  'TravelController ist noch nicht mit dem Dev Panel verbunden. '
                  'Sobald der richtige Provider-Name klar ist, wird er hier ergänzt.',
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ------------------------------------------------------------
// Helper für AsyncValue-Anzeige
// ------------------------------------------------------------
Widget buildAsyncTile(AsyncValue<dynamic> value) {
  return value.when(
    data: (data) => Text('Data:\n${data.toString()}'),
    loading: () => const Text('Loading...'),
    error: (e, st) => Text('Error: $e'),
  );
}
