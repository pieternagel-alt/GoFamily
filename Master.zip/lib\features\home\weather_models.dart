class WeatherData {
  final double temperature;
  final String condition;
  final String location;
  final DateTime? lastUpdated;
  final bool isFromCache;

  const WeatherData({
    required this.temperature,
    required this.condition,
    this.location = 'Unbekannt',
    this.lastUpdated,
    this.isFromCache = false,
  });

  WeatherData copyWith({
    double? temperature,
    String? condition,
    String? location,
    DateTime? lastUpdated,
    bool? isFromCache,
  }) {
    return WeatherData(
      temperature: temperature ?? this.temperature,
      condition: condition ?? this.condition,
      location: location ?? this.location,
      lastUpdated: lastUpdated ?? this.lastUpdated,
      isFromCache: isFromCache ?? this.isFromCache,
    );
  }
}
