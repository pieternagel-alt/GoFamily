import 'package:flutter/material.dart';

class TravelTestScreen extends StatelessWidget {
  const TravelTestScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Travel testen")),
      body: const Center(child: Text("Travel Test UI Stub")),
    );
  }
}
