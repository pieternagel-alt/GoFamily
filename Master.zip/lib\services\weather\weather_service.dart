import 'package:riverpod_annotation/riverpod_annotation.dart';

import '../../features/home/weather_models.dart';

part 'weather_service.g.dart';

class WeatherService {
  WeatherService();

  WeatherData? _cache;
  DateTime? _lastFetch;

  Future<WeatherData> loadWeather({String? location}) async {
    final now = DateTime.now();

    if (_cache != null &&
        _lastFetch != null &&
        now.difference(_lastFetch!) < const Duration(minutes: 10)) {
      return _cache!;
    }

    await Future.delayed(const Duration(milliseconds: 300));

    final data = WeatherData(
      temperature: 21.4,
      condition: 'Sonnig',
      location: location ?? 'Aktueller Standort',
      lastUpdated: now,
      isFromCache: false,
    );

    _cache = data.copyWith(isFromCache: true);
    _lastFetch = now;

    return data;
  }

  void clearCache() {
    _cache = null;
    _lastFetch = null;
  }
}

@riverpod
WeatherService weatherService(Ref ref) {
  return WeatherService();
}
