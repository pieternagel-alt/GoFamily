import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'features/shell/shell_screen.dart';

void main() {
  runApp(const ProviderScope(child: GoFamilyApp()));
}

class GoFamilyApp extends StatelessWidget {
  const GoFamilyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'GoFamily',
      theme: ThemeData.light(),
      darkTheme: ThemeData.dark(),
      home: const ShellScreen(),
    );
  }
}
