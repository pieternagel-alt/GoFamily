/// Platzhalter-Datei für zukünftig geteilte Controller.
///
/// v0.8: absichtlich leer, dient nur als struktureller Anker
/// für featureübergreifende Riverpod-Controller.
class SharedControllersPlaceholder {}
