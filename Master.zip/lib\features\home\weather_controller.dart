import 'package:riverpod_annotation/riverpod_annotation.dart';

import '../../services/weather/weather_service.dart';
import 'weather_models.dart';

part 'weather_controller.g.dart';

@riverpod
class WeatherController extends _$WeatherController {
  @override
  Future<WeatherData> build() async {
    final service = ref.watch(weatherServiceProvider);
    return service.loadWeather();
  }

  Future<void> refresh() async {
    state = const AsyncLoading();
    final service = ref.read(weatherServiceProvider);
    final data = await service.loadWeather();
    state = AsyncData(data);
  }
}
