import 'package:flutter/material.dart';

class MissionsTestScreen extends StatelessWidget {
  const MissionsTestScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Missionen testen")),
      body: const Center(child: Text("Missions Test UI Stub")),
    );
  }
}
