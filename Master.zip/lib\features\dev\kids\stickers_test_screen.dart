import 'package:flutter/material.dart';

class StickersTestScreen extends StatelessWidget {
  const StickersTestScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Sticker testen")),
      body: const Center(child: Text("Sticker Test UI Stub")),
    );
  }
}
